//
//  main.m
//  MQTT_alpha
//
//  Created by 北島知司 on 2015/03/10.
//  Copyright (c) 2015年 北島知司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
