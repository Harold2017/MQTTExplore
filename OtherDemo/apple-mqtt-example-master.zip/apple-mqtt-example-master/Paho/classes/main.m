@import UIKit;          // Apple
#import "AppDelegate.h" // MQTTKit

int main(int argc, char* argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
