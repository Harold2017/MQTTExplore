# MQTT-Client-Sample-with-two-libraries
This is a sample example for mqtt protocol using two library (IBM client for mobile  and Mqtt Kit)
