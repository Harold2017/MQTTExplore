//
//  ChatCell.m
//  MQTTChat
//
//  Created by Christoph Krey on 12.07.15.
//  Copyright (c) 2015 Owntracks. All rights reserved.
//

#import "ChatCell.h"

@implementation ChatCell

@end
